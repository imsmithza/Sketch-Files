## A Font Awesome 4.3.0 symbol library for [Sketch 3+](http://bohemiancoding.com/sketch/)

You will need to have [Font Awesome 4.3.0](http://fortawesome.github.io/Font-Awesome/) installed on in your local fonts for these symbols to work correctly


### Sketch Symbol Organization
![Symbol Organization](https://github.com/pixelsonly/font-awesome-sketch-symbols/blob/master/symbol-groups.png)

### Font Awesome 4.3.0 Icons
![Font Awesome 4.3.0 Symbols For Sketch 3](https://github.com/pixelsonly/font-awesome-sketch-symbols/blob/master/font-awesome-4.3.0-symbols.png)
