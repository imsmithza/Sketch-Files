# wireframingsketch
Set of simple Sketch symbols for wireframing.

- to change color please use Color Adjust on symbol
- for other direction you can Flip and Rotate symbol

![](https://raw.githubusercontent.com/mariuszostrowski/wireframingsketch/master/preview.gif)
